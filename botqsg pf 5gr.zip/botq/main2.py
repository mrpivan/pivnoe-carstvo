import telebot
from telebot.types import ReplyKeyboardMarkup, KeyboardButton, ReplyKeyboardRemove


token = "6590809114:AAFZN6vr6S2584wqbZIpOXhdgdKyEXSIAy4"
bot = telebot.TeleBot(token=token)

story = {
    'nachalo': { 
        'msge': "ты просыпаешься в повозке и ничего не помнишь. тебе говорят что ты избранный и вкалывают что то в шею. у тебя темнеет в глазах и у тебя в голове появляется три дороги",
        'img': 'povozka.jpg',
        'buttons': {
            "1": 'odin',
            "2": 'dva',
            "3": 'tri'
        },
           
    },
    'odin': {
        'msge': "перед тобой встает странное существо в черном облачении и предлагает тебе на выбор две таблетки: красную и синию. и говорит -примешь синию таблетку- и сказке конец. Ты проснешься в повозке и поверишь что это был просто сон. -примешь красную- войдешь в страну сказок. я тебе ее покажу",
        'img': 'tabletki.jpg',
        'buttons': {
            "синяя": 'blue',
            "красная": 'red'
        },
        
    },
    'blue': {
            'msge': "Выбрав синюю таблетку ты проснулся в повозке и начался сюжет скайрима. поздравляем с победой",
            'img': 'maxresdefault.jpg'
    },
    'red': {
        'msge': "выбрав красную таблетку вместо черного существа перед тобой встает морфеус, ты оказался киану ривзом и тебя позвала CDPR создавать киберпанк. поздравляю с победой",
        'img': 'kianu.jpg'
    },
    'dva': {
        'msge': "проснувшись в таверне тебе рассказывают, что на тебе висит долг и его надо закрыть. тебе дали на выбор два задания: 1) украсть и вернуть тиару из замка. но есть огромный риск попасться страже и умереть, зато ты покроешь весь долг, и тебя сверху накинут; 2) пойти в крипту и добыть оружие древнего могучего война. Задание простое, риск мал, но возможно ты утонешь или тебя убьют ловушки",
        'img': 'taverna.jpg',
        'buttons': {
            "украсть тиару": 'tiara',
            "пойти в крипту": 'kripta'
        }

    },
    'tiara': {
        'msge': "Ты смог пройти мимо стражи и попасть в замок. найдя нужный коридор ты нашел путь в коллекцию. попав внутрь ты увидел тиару и узнал в ней древнюю реликвию, за которую на черном рынке тебе дадут много денег. у тебя появился выбор, закончить задание или украсть и сбежать",
        'img': 'tiara.jpg',
        'buttons': {
            "закончить задание": 'konchit',
            "украсть": 'heist'
        }
    },
    'heist': {
        'msge': "ты выбрал сбежать. спустя неделю ты лежишь с коктейлем на шезлонге возле своего бассейна и смотришь на море из своей огромной виллы. думаешь о свободе и о своем везении вдруг в дверь стучаться. незнакомец представляется Вито Корлеоне и бьет ножом в грудь. фильм посмотрите, хороший. поражение",
        'img': 'ccicco.png'
    },
    'konchit': {
        'msge': "ты решил все таки закончить задание. ты погасил свой долг и тебе дали жилье. у тебя появилась семья. все счастливы",
        'img': 'semya.jpg'
    },
    'kripta': {
        'msge': "зайдя в крипту и пройдя несколько метров ты случайно нажал на кнопку в тебя из стен выстрелили куча стрел и ты умер поражение",
        'img': 'kripta.jpg'
    },
    'tri': {
        'msge': "пройдя по третьему пути ты открываешь дверь и попадаешь в пустую белую комнату. через время пол под тобой пропадает и ты падаешь в воду. в воде ты заметил два прохода и поплыл в одни из них",
        'img': 'cave.jpg',
        'buttons': {
            "налево": 'left',
            "направо": 'right'
        }
    },
    'left': {
        'msge': "поплыв налево ты попал в помещение. за тобой обрушился проход. ть в ловушке спустя пару дней ты умер от истощения. поражение",
        'img': 'mertv.jpg'
    },
    'right': {
        'msge': "поплыв направо ты увидел белый свет и поплыл за ним. спустя время он становился все ярче и ярче и ты проснулся в повозке и начался сюжет скайрима победа",
        'img': 'maxresdefault.jpg'
    }
}



@bot.message_handler(commands=['start'])
def handle_start(message):
    bot.send_message(message.chat.id, "Начнем квест")
    show_location(message, 'nachalo')
               
               
def show_location(message, location_name):
    location = story[location_name]
    photo = location['img']
    description = location['msge']
                       
    buttons = location.get('buttons')
    if buttons is not None:
        markup = ReplyKeyboardMarkup(resize_keyboard=True)
        for btn in buttons:
            markup.add(KeyboardButton (btn))
        
        bot.send_photo(message.chat.id, open(photo, 'rb'), description, reply_markup=markup) 
    
        bot.register_next_step_handler(message, process_answer, location_name)
    else:
        show_final(message, location_name)

def process_answer(message, location_name):
    location = story[location_name]
    answer = message.text
    next_location = location['buttons'].get(answer)
    if next_location is None:
        bot.send_message(message.chat.id, 'Ты дурак? Там кнопки есть')
        show_location(message, location_name)
    else:
        show_location(message, next_location)
    
    
def show_final(message, location_name):
    location = story[location_name]
    photo = location['img']
    description = location['msge']
    bot.send_photo(message.chat.id, open(photo, 'rb'), description, reply_markup=ReplyKeyboardRemove()) 
    

@bot.message_handler(content_types=['text', 'audio', 'photo'])
def send_text(message):
    bot.send_message(message.chat.id, 'Я тебя не понимаю, значит ты дурак, значит пропиши /start')
    
    
bot.polling()
    
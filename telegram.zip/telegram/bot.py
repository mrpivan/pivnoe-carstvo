import telebot
import requests
from m_A import info 

bot_token = '6754826188:AAEid2Mzmx0uTSpTbRvkFlLn4ozYj54OVJw'
bot = telebot.TeleBot('6754826188:AAEid2Mzmx0uTSpTbRvkFlLn4ozYj54OVJw')

@bot.message_handler(commands=['start'])
def start_message(message):
    bot.send_message(message.chat.id, 'Привет! Я бот. Напиши "/help"')

# Обработчик команды /help
@bot.message_handler(commands=['help'])
def help_message(message):
    text = '''Доступные комамнды
    /start - начать общение с ботом\n
    /help - получить помощь\n
    /info - получить информацию о Гендальфе Сером'''
    bot.send_message(message.chat.id, text)

# Обработчик команды /info
@bot.message_handler(commands=['info'])
def info_message(message):
    bot.send_message(message.chat.id, info)

# Обработчик текстовых сообщений
@bot.message_handler(func=lambda message: True)
def handle_text_messages(message):
    bot.send_message(message.chat.id, "Спасибо за сообщение!")

# Обработчик отправки фотографий
@bot.message_handler(content_types=['photo'])
def handle_photo(message):
    bot.send_message(message.chat.id, 'Красивая фотография!')

@bot.message_handler(commands=['phgen'])    
def send_character_photo(chat_id, character_name):
    character_photo_path = "ggendalf.PNG"
    files = {'phgen': open(character_photo_path, 'rb')}
    bot.send_message(files)


# Обработчик отправки медиафайлов
@bot.message_handler(content_types=['document', 'audio', 'voice', 'video'])
def handle_media(message):
    bot.send_message(message.chat.id, 'Спасибо за медиафайл!')
    

# Запускаем бота
bot.polling()